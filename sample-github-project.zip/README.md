# Sample GitHub Project

This is a sample project for learning how to upload files to GitHub.

## Files
- index.html
- style.css
- script.js

Open index.html in a browser.
